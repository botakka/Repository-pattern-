# Libary 

## Bevezető
A program egy könvytár adatait dolgozza fel ill. lehetőség van a könyveket kibérelni.
### Használt táblák
* Könvy
* Kölcsönzés
* olvasó