# OENIK_PROG3_2019_2_FLK8LL_CSSHARP


## Funkciólista
### Alapfunkcionalitás
* Kölcsönzés tábla adatainak kilistázása, bővítése, módosítása, törlése
* Olvasó tábla adatainak kilistázása, bővítése, módosítása, törlése
* Könyv tábla adatainak kilistázása, bővítése, módosítása, törlése
### Összetettebb műveletek
* Könyv Írója ABC sorrendben.
* Megadja melyik ügyfél kölcsönzött könyvet.
egész részét.
* Ki írja azokat a könyveket amiben van "S".
### Java végpont:
* Egyes könyvek bérlésenek időtartalma
