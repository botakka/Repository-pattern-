var searchData=
[
  ['ugyfel_39',['Ugyfel',['../class_my_libary_1_1_data_1_1_ugyfel.html',1,'MyLibary.Data.Ugyfel'],['../class_my_libary_1_1_program_1_1_ugyfel.html',1,'MyLibary.Program.Ugyfel']]],
  ['updatebookname_40',['UpdateBookName',['../interface_my_libary_1_1_repository_1_1_i_libary_repository.html#abb7aa89bde303b36e70db437116d45c7',1,'MyLibary.Repository.ILibaryRepository.UpdateBookName()'],['../class_my_libary_1_1_repository_1_1_repository.html#ae6427042fbaca8d40c8d29c51d6f58f1',1,'MyLibary.Repository.Repository.UpdateBookName()']]]
];
