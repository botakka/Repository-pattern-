var searchData=
[
  ['getall_64',['GetAll',['../interface_my_libary_1_1_repository_1_1_i_repository.html#a2fc7523eb462e6982e89b26ee4d44280',1,'MyLibary::Repository::IRepository']]],
  ['getallclient_65',['GetAllClient',['../interface_my_libary_1_1_repository_1_1_i_repository.html#a8f8b3cd8bdbe5a1f809536ac365a61f5',1,'MyLibary::Repository::IRepository']]],
  ['getone_66',['GetOne',['../interface_my_libary_1_1_repository_1_1_i_repository.html#ac0f51ebba57fbcbfbac708f0017686ba',1,'MyLibary.Repository.IRepository.GetOne()'],['../class_my_libary_1_1_repository_1_1_repository.html#ad4328d4954520af9d8ef5c7037d4c4f2',1,'MyLibary.Repository.Repository.GetOne()']]],
  ['getoneclient_67',['GetOneClient',['../interface_my_libary_1_1_repository_1_1_i_repository.html#a21cce9d8290a4ec1a2bd7f43907dbc7b',1,'MyLibary::Repository::IRepository']]]
];
