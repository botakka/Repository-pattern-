var searchData=
[
  ['delete_63',['Delete',['../interface_my_libary_1_1_repository_1_1_i_libary_repository.html#ac018a238039ee492d40e9a1eccb9e9e4',1,'MyLibary.Repository.ILibaryRepository.Delete()'],['../class_my_libary_1_1_repository_1_1_repository.html#a5e8ca231fa06352bc711b64c030282ec',1,'MyLibary.Repository.Repository.Delete()']]]
];
