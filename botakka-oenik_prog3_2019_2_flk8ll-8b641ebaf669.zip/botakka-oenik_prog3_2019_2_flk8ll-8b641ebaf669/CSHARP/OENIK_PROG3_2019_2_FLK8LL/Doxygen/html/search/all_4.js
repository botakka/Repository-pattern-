var searchData=
[
  ['ilibaryrepository_12',['ILibaryRepository',['../interface_my_libary_1_1_repository_1_1_i_libary_repository.html',1,'MyLibary::Repository']]],
  ['ilogic_13',['ILogic',['../interface_my_libary_1_1_logic_1_1_i_logic.html',1,'MyLibary::Logic']]],
  ['irepository_14',['IRepository',['../interface_my_libary_1_1_repository_1_1_i_repository.html',1,'MyLibary::Repository']]],
  ['irepository_3c_20konyv_20_3e_15',['IRepository&lt; Konyv &gt;',['../interface_my_libary_1_1_repository_1_1_i_repository.html',1,'MyLibary::Repository']]]
];
