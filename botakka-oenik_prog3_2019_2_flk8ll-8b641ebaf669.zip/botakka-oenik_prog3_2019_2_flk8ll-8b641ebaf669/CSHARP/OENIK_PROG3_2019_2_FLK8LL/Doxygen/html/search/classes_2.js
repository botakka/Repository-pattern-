var searchData=
[
  ['kolcsonze_46',['Kolcsonze',['../class_my_libary_1_1_program_1_1_kolcsonze.html',1,'MyLibary.Program.Kolcsonze'],['../class_my_libary_1_1_data_1_1_kolcsonze.html',1,'MyLibary.Data.Kolcsonze']]],
  ['konyv_47',['Konyv',['../class_my_libary_1_1_program_1_1_konyv.html',1,'MyLibary.Program.Konyv'],['../class_my_libary_1_1_data_1_1_konyv.html',1,'MyLibary.Data.Konyv']]]
];
