var searchData=
[
  ['repository_38',['Repository',['../class_my_libary_1_1_repository_1_1_repository.html',1,'MyLibary.Repository.Repository'],['../class_my_libary_1_1_repository_1_1_repository.html#abab9c43427ba8fb5e112a905d43c505d',1,'MyLibary.Repository.Repository.Repository()']]]
];
