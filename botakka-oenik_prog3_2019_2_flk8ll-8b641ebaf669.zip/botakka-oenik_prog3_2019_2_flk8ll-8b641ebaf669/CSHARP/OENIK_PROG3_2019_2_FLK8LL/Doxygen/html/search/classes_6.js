var searchData=
[
  ['ugyfel_54',['Ugyfel',['../class_my_libary_1_1_data_1_1_ugyfel.html',1,'MyLibary.Data.Ugyfel'],['../class_my_libary_1_1_program_1_1_ugyfel.html',1,'MyLibary.Program.Ugyfel']]]
];
