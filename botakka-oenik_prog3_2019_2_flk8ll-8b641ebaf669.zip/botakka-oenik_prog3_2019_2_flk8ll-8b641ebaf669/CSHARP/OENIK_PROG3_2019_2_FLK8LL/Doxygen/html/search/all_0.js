var searchData=
[
  ['add_0',['Add',['../interface_my_libary_1_1_repository_1_1_i_libary_repository.html#aa23a8b64cfcb1cbe371689ad14b18073',1,'MyLibary.Repository.ILibaryRepository.Add()'],['../class_my_libary_1_1_repository_1_1_repository.html#a1104df2902b48f002da37900bdcca6a6',1,'MyLibary.Repository.Repository.Add()']]]
];
