﻿insert into Kolcsonzes values (1,2,1998-05-25,3,'It was allrigth!');
insert into Kolcsonzes values (4,4,1990-04-25,5,'It was allrigth!');
insert into Kolcsonzes values (5,7,2008-04-22,6,'It was allrigth!');
insert into Kolcsonzes values (7,2,1998-05-25,2,'It was allrigth!');
insert into Kolcsonzes values (8,3,1999-05-25,10,'It was allrigth!');
insert into Kolcsonzes values (3,6,1994-03-25,1,'It was allrigth!');