# OENIK_PROG3_2019_2_FLK8LL_JAVA

## Funkcionalitás
Ez a Java végpont megkap egy tetszőleges könyvet annak szerzőjét címét eltárolja és kiszámítja naponként mennyi bérlési díjat kell számolni ill.késedelmi kamatot.